﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EFWorkshop.Migrations
{
    public partial class AddRawDataToCategory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("insert into Categories values('Poetry',5)");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
