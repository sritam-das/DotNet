﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using WorkshopWithContextFactory;

namespace EFWorkshop
{
    class Program
    {
        public static BooksDBContextFactory contextFactory = new BooksDBContextFactory();
        public static void AddCategory()
        {
            using (var context = contextFactory.CreateDbContext())
            {
                List<Category> categories = new List<Category>();
                categories.Add(new Category { CategoryName = "Fiction", BookId = 1 });
                categories.Add(new Category { CategoryName = "Mystery", BookId = 2 });
                categories.Add(new Category { CategoryName = "Drama", BookId = 3 });
                categories.Add(new Category { CategoryName = "Action", BookId = 4 });
                categories.Add(new Category { CategoryName = "Crime", BookId = 5 });
                categories.Add(new Category { CategoryName = "Thriller", BookId = 6 });
                categories.Add(new Category { CategoryName = "Comic", BookId = 7 });
                categories.Add(new Category { CategoryName = "Romance", BookId = 8 });
                categories.Add(new Category { CategoryName = "Suspense", BookId = 9 });
                categories.Add(new Category { CategoryName = "Classic", BookId = 10 });
                foreach (Category item in categories)
                {
                    context.Categories.Add(item);

                }
                context.SaveChanges();
                Console.WriteLine("Data Added sccessfully");
            }
        }
        public static void AddBookAndAuthors()
        {
            using (var context = contextFactory.CreateDbContext())
            {
                List<Author> authors = new List<Author>();
                List<Book> books = new List<Book>();
                var var1 = (new Book { Title = "House Of The Flies", CategoryId = 1, AuthorsList = new List<Author>() });
                var var2 = (new Book { Title = "The Silent Patient", CategoryId = 2, AuthorsList = new List<Author>() });
                var var3 = (new Book { Title = "Harry Potter", CategoryId = 3, AuthorsList = new List<Author>() });
                var var4 = (new Book { Title = "The Hunger Games", CategoryId = 4, AuthorsList = new List<Author>() });
                var var5 = (new Book { Title = "Unspeakable", CategoryId = 5, AuthorsList = new List<Author>() });
                var var6 = (new Book { Title = "Faithless", CategoryId = 6, AuthorsList = new List<Author>() });
                var var7 = (new Book { Title = "The Alchemist", CategoryId = 7, AuthorsList = new List<Author>() });
                var var8 = (new Book { Title = "The Art Of Living", CategoryId = 8, AuthorsList = new List<Author>() });
                var var9 = (new Book { Title = "Deep Water", CategoryId = 9, AuthorsList = new List<Author>() });
                var var10 = (new Book { Title = "The Science Of Getting Rich", CategoryId = 10, AuthorsList = new List<Author>() });
                var var11 = (new Book { Title = "The Ickabog", CategoryId = 3, AuthorsList = new List<Author>() });

                var author1 = (new Author { FirstName = "William", LastName = "Golding" });
                var author2 = (new Author { FirstName = "Alex", LastName = "Michaelides" });
                var author3 = (new Author { FirstName = "J.K.", LastName = "Rowling" });
                var author4 = (new Author { FirstName = "Suzanne", LastName = "Collins" });
                var author5 = (new Author { FirstName = "Sandra", LastName = "Brown" });
                var author6 = (new Author { FirstName = "Karin", LastName = "Slaughter" });
                var author7 = (new Author { FirstName = "Paulo", LastName = "Coelho" });
                var author8 = (new Author { FirstName = "Erich", LastName = "Fromm" });
                var author9 = (new Author { FirstName = "Patricia", LastName = "Highsmith" });
                var author10 = (new Author { FirstName = "Wallace", LastName = "Wattles" });

                var1.AuthorsList.Add(author1);
                var2.AuthorsList.Add(author2);
                var3.AuthorsList.Add(author3);
                var4.AuthorsList.Add(author4);
                var5.AuthorsList.Add(author5);
                var6.AuthorsList.Add(author6);
                var7.AuthorsList.Add(author7);
                var8.AuthorsList.Add(author8);
                var9.AuthorsList.Add(author9);
                var10.AuthorsList.Add(author10);
                var11.AuthorsList.Add(author3);

                books.Add(var1);
                books.Add(var2);
                books.Add(var3);
                books.Add(var4);
                books.Add(var5);
                books.Add(var6);
                books.Add(var7);
                books.Add(var8);
                books.Add(var9);
                books.Add(var10);
                books.Add(var11);

                authors.Add(author1);
                authors.Add(author2);
                authors.Add(author3);
                authors.Add(author4);
                authors.Add(author5);
                authors.Add(author6);
                authors.Add(author7);
                authors.Add(author8);
                authors.Add(author9);
                authors.Add(author10);

                foreach (Book item in books)
                {
                    context.Books.Add(item);

                }
                foreach (Author item in authors)
                {
                    context.Authors.Add(item);

                }
                context.SaveChanges();
                Console.WriteLine("Data Added sccessfully");
            }
        }

        public static void AddAutoBiography()
        {
            using (var context = contextFactory.CreateDbContext())
            {
                List<AutoBiography> biographies = new List<AutoBiography>();
                biographies.Add(new AutoBiography { BiographyTitle = "House Of The Flies", DateOfBirth = new DateTime(1911, 09, 19), PlaceOfBirth = "England", Nationality = "British", AuthorId = 1 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Silent Patient", DateOfBirth = new DateTime(1977, 07, 29), PlaceOfBirth = "England", Nationality = "British", AuthorId = 2 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Ickabog", DateOfBirth = new DateTime(1965, 07, 31), PlaceOfBirth = "England", Nationality = "British", AuthorId = 3 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Hunger Games", DateOfBirth = new DateTime(1962, 08, 10), PlaceOfBirth = "Hartford", Nationality = "American", AuthorId = 4 });
                biographies.Add(new AutoBiography { BiographyTitle = "Unspeakable", DateOfBirth = new DateTime(1948, 03, 12), PlaceOfBirth = "Texas", Nationality = "American", AuthorId = 5 });
                biographies.Add(new AutoBiography { BiographyTitle = "Faithless", DateOfBirth = new DateTime(1971, 01, 06), PlaceOfBirth = "Atlanta", Nationality = "American", AuthorId = 6 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Alchemist", DateOfBirth = new DateTime(1947, 08, 24), PlaceOfBirth = "Rio De Janerio", Nationality = "Brazilian", AuthorId = 7 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Art Of Living", DateOfBirth = new DateTime(1900, 03, 23), PlaceOfBirth = "Frankfurt", Nationality = "German", AuthorId = 8 });
                biographies.Add(new AutoBiography { BiographyTitle = "Deep Water", DateOfBirth = new DateTime(1921, 01, 19), PlaceOfBirth = "Atlanta", Nationality = "American", AuthorId = 9 });
                biographies.Add(new AutoBiography { BiographyTitle = "The Science Of Getting Rich", DateOfBirth = new DateTime(1880, 05, 09), PlaceOfBirth = "Illinois", Nationality = "American", AuthorId = 10 });
                foreach (AutoBiography item in biographies)
                {
                    context.Autobiographies.Add(item);

                }
                context.SaveChanges();
                Console.WriteLine("Data Added sccessfully");
            }
            Console.WriteLine("--------------------------------------------------");
        }

        //Retrieve the authors of the book name provided by the user
        
            public static void GetAuthorsOfBookName(string bookName)
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var bookData = context.Books
                        .Where(book => book.Title == bookName).Include(book => book.AuthorsList);


                    foreach (var book in bookData)
                    {
                        foreach (var author in book.AuthorsList)
                        {
                            Console.WriteLine("Author of the book is/are:" + author.FirstName + " " + author.LastName);
                        }
                    };
                }
                Console.WriteLine("--------------------------------------------------");
            }
            //Retrieve all the books written by a particular author
            public static void GetBookNameFromAuthor(string authorName)
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var authorData = context.Authors
                        .Where(author => (author.FirstName + " " + author.LastName) == authorName).Include(author => author.booksList);
                    foreach (var author in authorData)
                    {
                        foreach (var book in author.booksList)
                        {
                            Console.WriteLine("Book written by particular author is:" + book.Title);
                        }
                    };
                }
                Console.WriteLine("--------------------------------------------------");
            }
            public static void getBookByBookId(int bookid)
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var book = context.Books
                        .Where(book => book.BookId == bookid)
                        .Single<Book>();
                    Console.WriteLine("Name of the book with the specified id is:" + book.Title);
                }
                Console.WriteLine("--------------------------------------------------");
            }
            //Display the autobiography name of the author whose name is specified
            public static void getAutoBiographyByAuthorName(string name)
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var autobiography = context.Authors
                        .Where(author => author.FirstName == name)
                        .Include(author => author.BiographyId).FirstOrDefault();
                    Console.WriteLine("Name of autobiography written by author name specified is:" + autobiography.BiographyId.BiographyTitle);
                }
                Console.WriteLine("--------------------------------------------------");
            }
            //Retrieve all the books from a particular category
            public static void getAllBooksFromCategory(string name)
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var books = context.Books
                        .Where(book => book.Category.CategoryName == name)
                        .ToList();
                    foreach (var book in books)
                    {
                        Console.WriteLine("Books in category:" + book.Title);
                    }
                }
                Console.WriteLine("--------------------------------------------------");
            }
            // Modify the last name of a particular author
            public static void modifyLastNameOfAuthor()
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var updateLastName = context.Authors
                        .First(author => author.AuthorId == 10);
                    updateLastName.LastName = "Wan";
                    context.Update(updateLastName);
                    context.SaveChanges();
                    Console.WriteLine("Last name updated successfully");
                }
                Console.WriteLine("--------------------------------------------------");
            }
            //Delete the author and his corresponding books provided by the user
            public static void deleteAuthorandBooks()
            {
                using (var context = contextFactory.CreateDbContext())
                {
                    var authorToBeDeleted = context.Authors.Where(author => author.AuthorId == 4).Include(author => author.booksList);

                    foreach (var book in authorToBeDeleted)
                    {
                        context.RemoveRange(book.booksList);
                    }
                    context.RemoveRange(authorToBeDeleted);
                    context.SaveChanges();
                    Console.WriteLine("Data is deleted");
                }
                Console.WriteLine("--------------------------------------------------");
             }

    public static void Main(string[] args)
        {
            //AddCategory();
            //AddBookAndAuthors();
            //AddAutoBiography();
            //GetAuthorsOfBookName("Harry Potter");
            getBookByBookId(5);
            getAutoBiographyByAuthorName("Alex");
            getAllBooksFromCategory("Drama");
            modifyLastNameOfAuthor();
            GetBookNameFromAuthor("J.K. Rowling");
            //deleteAuthorandBooks();
        }
    }
}

