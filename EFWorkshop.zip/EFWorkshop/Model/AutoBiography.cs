﻿using System;
using System.ComponentModel.DataAnnotations;


namespace WorkshopWithContextFactory
{
    public class AutoBiography
    {
        [Key]
        public int AuthorBiographyId { get; set; }
        public string BiographyTitle { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string Nationality { get; set; }
        public int AuthorId { get; set; }
        public Author Author { get; set; }
    }
}
